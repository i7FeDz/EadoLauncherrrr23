@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"
set ADB=adb
if exist "%~dp0adb.exe" set ADB="%~dp0adb.exe"
echo ===== Eado Plus Launcher =====
%ADB% devices
echo.
echo [1/3] Installing the launcher...
%ADB% install -r -g app-debug.apk
if errorlevel 1 goto fail
echo.
echo [2/3] Installing your apps (folder "apps")...
for %%f in (apps\*.apk) do (
  echo  - %%~nxf
  %ADB% install -r -g "%%f"
)
for /d %%d in (apps\*) do (
  set LIST=
  for %%f in ("%%d\*.apk") do set LIST=!LIST! "%%f"
  echo  - %%~nxd
  %ADB% install-multiple -r -g !LIST!
)
echo.
echo [3/3] Turning on features...
%ADB% push setup_device.sh /data/local/tmp/setup_device.sh
%ADB% shell sh /data/local/tmp/setup_device.sh
echo.
echo Finished. Look at the car screen.
pause
exit /b 0
:fail
echo.
echo Install failed: check the USB cable, ADB mode on the car, and accept the prompt on the car screen.
pause
exit /b 1
