#!/bin/sh
# Mac / Linux version of install.bat
cd "$(dirname "$0")"
ADB=adb; [ -x ./adb ] && ADB=./adb
echo "===== Eado Plus Launcher ====="
$ADB devices
$ADB install -r -g app-debug.apk || { echo "Install failed: check cable / ADB mode"; exit 1; }
for f in apps/*.apk; do [ -f "$f" ] && echo " - $f" && $ADB install -r -g "$f"; done
for d in apps/*/; do [ -d "$d" ] && echo " - $d" && $ADB install-multiple -r -g "$d"*.apk; done
$ADB push setup_device.sh /data/local/tmp/setup_device.sh
$ADB shell sh /data/local/tmp/setup_device.sh
echo "Finished. Look at the car screen."
