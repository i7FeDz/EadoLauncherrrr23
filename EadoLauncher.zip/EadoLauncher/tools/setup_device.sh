# Runs ON the car screen (pushed by install.bat / install.sh). Turns on the launcher's features.
PKG=com.fahad.eadolauncher
appops set $PKG SYSTEM_ALERT_WINDOW allow   # hidden button
appops set $PKG WRITE_SETTINGS allow        # full-screen brightness
cmd notification allow_listener $PKG/$PKG.MediaListener   # song title + cover
SVC=$PKG/$PKG.SplitService                  # split screen (keeps other services on)
CUR=$(settings get secure enabled_accessibility_services)
case "$CUR" in
  *"$SVC"*) ;;
  ""|null) settings put secure enabled_accessibility_services "$SVC" ;;
  *) settings put secure enabled_accessibility_services "$CUR:$SVC" ;;
esac
settings put secure accessibility_enabled 1
cmd package set-home-activity $PKG/.MainActivity   # make it the home screen
am start -n $PKG/.MainActivity
echo "DONE"
