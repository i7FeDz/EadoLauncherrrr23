package com.fahad.eadolauncher

import android.app.Activity
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

/** Opens the original Changan home screen (where the climate and drive modes live). */
object Original {
    fun open(a: Activity, forceChoose: Boolean = false) {
        val saved = Prefs.get(a, "orig")
        if (!forceChoose && saved != null && AppUtils.launch(a, saved)) return

        val homes = AppUtils.homeApps(a)
        if (homes.isEmpty()) {
            Toast.makeText(a, R.string.no_original, Toast.LENGTH_SHORT).show(); return
        }
        if (homes.size == 1 && !forceChoose) {
            val f = AppUtils.flat(homes[0])
            Prefs.put(a, "orig", f)
            if (!AppUtils.launch(a, f)) Toast.makeText(a, R.string.cant_open, Toast.LENGTH_SHORT).show()
            return
        }
        val labels = homes.map { it.loadLabel(a.packageManager).toString() }.toTypedArray()
        AlertDialog.Builder(a)
            .setTitle(R.string.choose_original)
            .setItems(labels) { _, i ->
                val f = AppUtils.flat(homes[i])
                Prefs.put(a, "orig", f)
                if (!AppUtils.launch(a, f)) Toast.makeText(a, R.string.cant_open, Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    /** Opens the app saved under [key]; if none, the original Changan system. */
    fun openKeyOrOriginal(a: Activity, key: String) {
        if (!AppUtils.launch(a, Prefs.get(a, key))) open(a)
    }
}
