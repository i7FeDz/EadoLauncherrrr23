package com.fahad.eadolauncher

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Outline
import android.graphics.RectF
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject
import org.osmdroid.config.Configuration as OsmConfig
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.TilesOverlay
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : BaseActivity() {

    private lateinit var greeting: TextView
    private lateinit var dateLine: TextView
    private lateinit var speedText: TextView
    private lateinit var driveState: TextView
    private lateinit var gearChip: TextView
    private lateinit var carPhoto: ImageView
    private lateinit var glowFar: View
    private lateinit var glowNear: View
    private lateinit var glowMirror: View
    private lateinit var beamFar: View
    private lateinit var beamNear: View
    private lateinit var map: MapView
    private lateinit var mapCity: TextView
    private lateinit var navApp: TextView
    private lateinit var navAppIcon: ImageView
    private lateinit var mediaSource: TextView
    private lateinit var mediaTitle: TextView
    private lateinit var mediaArtist: TextView
    private lateinit var mediaArt: ImageView
    private lateinit var mediaProgress: ProgressBar
    private lateinit var mediaPos: TextView
    private lateinit var mediaDur: TextView
    private lateinit var btnPlay: ImageButton
    private lateinit var weatherIcon: ImageView
    private lateinit var weatherTemp: TextView
    private lateinit var climateCard: View
    private lateinit var tempText: TextView
    private lateinit var fanText: TextView

    private var myLocation: MyLocationNewOverlay? = null
    private val chipViews = mutableListOf<TextView>()
    private val hvacViews = mutableMapOf<Int, View>()
    private var hvac = false

    private val handler = Handler(Looper.getMainLooper())
    private var locationManager: LocationManager? = null
    private var lastFixTime = 0L
    @Volatile private var lastGeocode = 0L
    @Volatile private var lastWeather = 0L
    @Volatile private var weatherJson: JSONObject? = null

    private var sessionManager: MediaSessionManager? = null
    private var controller: MediaController? = null

    // ---- choosing apps (shortcuts, split screen) ----
    private var pendingKey: String? = null
    private var splitFirst: String? = null
    private val pickApp = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val key = pendingKey ?: return@registerForActivityResult
        pendingKey = null
        val comp = res.data?.getStringExtra(AppsActivity.EXTRA_RESULT)
        if (res.resultCode != RESULT_OK || comp == null) { splitFirst = null; return@registerForActivityResult }
        when (key) {
            "@split1" -> { splitFirst = comp; pick("@split2", R.string.split_pick_second) }
            "@split2" -> {
                val first = splitFirst; splitFirst = null
                if (first != null && !SplitService.run(first, comp)) explainSplit()
            }
            else -> { Prefs.put(this, key, comp); refreshShortcuts() }
        }
    }

    companion object {
        private const val HV_AUTO = 0
        private const val HV_AC = 1
        private const val HV_RECIRC = 2
        private const val HV_REAR = 3
        private const val HV_POWER = 4
        private const val HV_MORE = 5
        private const val HOFUF_LAT = 25.3833
        private const val HOFUF_LON = 49.5864
    }

    // =========================== lifecycle ===========================

    override fun onCreate(savedInstanceState: Bundle?) {
        OsmConfig.getInstance().apply {
            userAgentValue = packageName
            osmdroidBasePath = File(cacheDir, "osmdroid")
            osmdroidTileCache = File(cacheDir, "osmdroid/tiles")
        }
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        pendingKey = savedInstanceState?.getString("pendingKey")
        splitFirst = savedInstanceState?.getString("splitFirst")

        greeting = findViewById(R.id.greeting)
        dateLine = findViewById(R.id.dateLine)
        speedText = findViewById(R.id.speed)
        driveState = findViewById(R.id.driveState)
        gearChip = findViewById(R.id.gearChip)
        carPhoto = findViewById(R.id.carPhoto)
        glowFar = findViewById(R.id.glowFar)
        glowNear = findViewById(R.id.glowNear)
        glowMirror = findViewById(R.id.glowMirror)
        beamFar = findViewById(R.id.beamFar)
        beamNear = findViewById(R.id.beamNear)
        mapCity = findViewById(R.id.mapCity)
        navApp = findViewById(R.id.navApp)
        navAppIcon = findViewById(R.id.navAppIcon)
        mediaSource = findViewById(R.id.mediaSource)
        mediaTitle = findViewById(R.id.mediaTitle)
        mediaArtist = findViewById(R.id.mediaArtist)
        mediaArt = findViewById(R.id.mediaArt)
        mediaProgress = findViewById(R.id.mediaProgress)
        mediaPos = findViewById(R.id.mediaPos)
        mediaDur = findViewById(R.id.mediaDur)
        btnPlay = findViewById(R.id.btnPlay)
        weatherIcon = findViewById(R.id.weatherIcon)
        weatherTemp = findViewById(R.id.weatherTemp)
        climateCard = findViewById(R.id.climateCard)
        tempText = findViewById(R.id.tempText)
        fanText = findViewById(R.id.fanText)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {}
        })

        CarBridge.connect(this)
        firstRunDefaults()
        buildSidebar()
        buildDriveModes()
        buildQuickRow()
        buildMediaChips()
        buildClimateGrid()
        setupMap()
        roundArt()

        findViewById<View>(R.id.btnQuick).setOnClickListener { showQuickPanel() }
        findViewById<View>(R.id.btnSettings).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        findViewById<View>(R.id.btnChangan).setOnClickListener { Original.open(this) }
        findViewById<View>(R.id.btnChangan).setOnLongClickListener { Original.open(this, true); true }
        findViewById<View>(R.id.weatherChip).setOnClickListener { showWeather() }

        findViewById<View>(R.id.autoHold).setOnClickListener { openVehicle("autohold") }
        findViewById<View>(R.id.autoHold).setOnLongClickListener { pick("autohold"); true }

        findViewById<View>(R.id.whereTo).setOnClickListener { openKnown(AppDefs.GMAPS, "nav") }
        findViewById<View>(R.id.whereTo).setOnLongClickListener { pick("nav"); true }
        findViewById<View>(R.id.mediaCard).setOnClickListener {
            val c = controller
            when {
                !hasMediaAccess() -> openSettingsAction("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
                c != null -> AppUtils.launchPackage(this, c.packageName)
                else -> launchOrPick("music")
            }
        }
        findViewById<View>(R.id.btnPrev).setOnClickListener { media(KeyEvent.KEYCODE_MEDIA_PREVIOUS) }
        findViewById<View>(R.id.btnNext).setOnClickListener { media(KeyEvent.KEYCODE_MEDIA_NEXT) }
        btnPlay.setOnClickListener { media(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }

        findViewById<View>(R.id.tempDown).setOnClickListener { stepTemp(-0.5f) }
        findViewById<View>(R.id.tempUp).setOnClickListener { stepTemp(0.5f) }
        findViewById<View>(R.id.fanDown).setOnClickListener { stepFan(-1) }
        findViewById<View>(R.id.fanUp).setOnClickListener { stepFan(1) }
        findViewById<View>(R.id.climateMore).setOnClickListener { openVehicle("climate") }

        Ui.polish(window.decorView)
        carPhoto.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> placeLights() }

        val wanted = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            "android.car.permission.CAR_SPEED"
        ).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (wanted.isNotEmpty()) requestPermissions(wanted.toTypedArray(), 1)

        OverlayService.start(this)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("pendingKey", pendingKey)
        outState.putString("splitFirst", splitFirst)
    }

    override fun onResume() {
        super.onResume()
        updateGreeting()
        map.onResume()
        refreshShortcuts()
        startLocation()
        startMedia()
        maybeFetchWeather()
        handler.post(tick)
        handler.post(blink)
    }

    override fun onPause() {
        super.onPause()
        map.onPause()
        stopLocation()
        stopMedia()
        handler.removeCallbacks(tick)
        handler.removeCallbacks(blink)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        CarBridge.reset()
        CarBridge.connect(this)
        startLocation()
    }

    /** every second: greeting, internet, speed & gear, climate, music progress, weather refresh */
    private val tick = object : Runnable {
        override fun run() {
            updateGreeting()
            NetUtils.bindChip(this@MainActivity)
            val carSpeed = CarBridge.speedKmh()
            if (carSpeed != null) showSpeed(carSpeed)
            else if (System.currentTimeMillis() - lastFixTime > 5000) {
                speedText.text = "--"
                driveState.setText(R.string.state_waiting)
            }
            val gear = CarBridge.gearLetter()
            gearChip.visibility = if (gear == null) View.GONE else View.VISIBLE
            gearChip.text = gear ?: ""
            refreshClimate()
            updateProgress()
            maybeFetchWeather()
            handler.postDelayed(this, 1000)
        }
    }

    private fun updateGreeting() {
        greeting.text = getString(if (Ui.isMorning()) R.string.greet_morning else R.string.greet_evening, Prefs.name(this))
        dateLine.text = Ui.dateLine(this)
    }

    private fun showSpeed(kmh: Int) {
        speedText.text = kmh.toString()
        driveState.setText(if (kmh > 3) R.string.state_moving else R.string.state_stopped)
    }

    // =========================== car lights on the photo ===========================

    /** Positions (as a fraction of the photo) of the far lamp, near lamp and the side mirror. */
    private fun placeLights() {
        val d = carPhoto.drawable ?: return
        val r = RectF(0f, 0f, d.intrinsicWidth.toFloat(), d.intrinsicHeight.toFloat())
        carPhoto.imageMatrix.mapRect(r)
        fun put(v: View, fx: Float, fy: Float) {
            val lp = v.layoutParams as FrameLayout.LayoutParams
            lp.gravity = Gravity.TOP or Gravity.LEFT
            lp.leftMargin = (r.left + r.width() * fx - lp.width / 2f).roundToInt()
            lp.topMargin = (r.top + r.height() * fy - lp.height / 2f).roundToInt()
            v.layoutParams = lp
        }
        put(glowFar, 0.045f, 0.36f); put(beamFar, 0.045f, 0.36f)
        put(glowNear, 0.33f, 0.40f); put(beamNear, 0.33f, 0.40f)
        put(glowMirror, 0.60f, 0.29f)
    }

    private var blinkOn = false
    private val blink = object : Runnable {
        override fun run() {
            blinkOn = !blinkOn
            val turn = CarBridge.turnSignal()
            val hazard = CarBridge.hazard() == true
            val left = hazard || turn == 2
            val right = hazard || turn == 1
            glowFar.visibility = if (left && blinkOn) View.VISIBLE else View.INVISIBLE
            glowNear.visibility = if (right && blinkOn) View.VISIBLE else View.INVISIBLE
            glowMirror.visibility = if (right && blinkOn) View.VISIBLE else View.INVISIBLE
            val beams = CarBridge.headlights() == true
            beamFar.visibility = if (beams) View.VISIBLE else View.INVISIBLE
            beamNear.visibility = beamFar.visibility
            handler.postDelayed(this, 450)
        }
    }

    // =========================== sidebar (icons only) ===========================

    private fun buildSidebar() {
        val side = findViewById<LinearLayout>(R.id.sideNav)
        val items = listOf(
            Triple(R.drawable.ic_home, R.string.nav_home, "@home"),
            Triple(R.drawable.ic_nav, R.string.navigation, "@maps"),
            Triple(R.drawable.ic_music, R.string.nav_music, "music"),
            Triple(R.drawable.ic_tv, R.string.nav_fun, "@fun"),
            Triple(R.drawable.ic_phone, R.string.nav_phone, "phone"),
            Triple(R.drawable.ic_vehicle, R.string.nav_vehicle, "@vehicle"),
            Triple(R.drawable.ic_apps, R.string.nav_apps, "@apps")
        )
        val dim = ColorStateList.valueOf(getColor(R.color.text_dim))
        val accent = ColorStateList.valueOf(Ui.accent(this))
        items.forEachIndexed { i, (icon, label, key) ->
            val v = layoutInflater.inflate(R.layout.item_nav, side, false)
            val iv = v.findViewById<ImageView>(R.id.navIcon)
            iv.setImageResource(icon)
            iv.imageTintList = if (i == 0) accent else dim
            v.contentDescription = getString(label)
            if (i == 0) v.setBackgroundResource(R.drawable.bg_nav_selected)
            when (key) {
                "@home" -> {}
                "@maps" -> { v.setOnClickListener { openKnown(AppDefs.GMAPS, "nav") }; v.setOnLongClickListener { pick("nav"); true } }
                "@fun" -> v.setOnClickListener { startActivity(Intent(this, EntertainmentActivity::class.java)) }
                "@apps" -> v.setOnClickListener { startActivity(Intent(this, AppsActivity::class.java)) }
                "@vehicle" -> { v.setOnClickListener { openVehicle("vehicle") }; v.setOnLongClickListener { pick("vehicle"); true } }
                else -> bindApp(v, key)
            }
            side.addView(v)
        }
    }

    // =========================== drive mode, car shortcuts, dock ===========================

    private fun buildDriveModes() {
        val box = findViewById<LinearLayout>(R.id.driveModes)
        listOf(R.string.drive_eco to 0xFF3E9B5F.toInt(), R.string.drive_normal to 0xFF3D7BD9.toInt(),
            R.string.drive_sport to 0xFFC9444C.toInt()).forEach { (name, color) ->
            val tv = TextView(this).apply {
                setText(name)
                textSize = 15f
                gravity = Gravity.CENTER
                setTextColor(getColor(R.color.text))
                setPadding(Ui.dp(context, 8), 0, Ui.dp(context, 14), 0)
            }
            val dot = View(this).apply {
                setBackgroundResource(R.drawable.bg_round)
                backgroundTintList = ColorStateList.valueOf(color)
            }
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(Ui.dp(context, 10), 0, 0, 0)
                isClickable = true
                setBackgroundResource(R.drawable.bg_toggle)
                addView(dot, LinearLayout.LayoutParams(Ui.dp(context, 10), Ui.dp(context, 10)))
                addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
                setOnClickListener { openVehicle("drive") }
                setOnLongClickListener { pick("drive"); true }
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
            if (box.childCount > 0) lp.marginStart = Ui.dp(this, 4)
            box.addView(cell, lp)
        }
    }

    private fun buildQuickRow() {
        val row = findViewById<LinearLayout>(R.id.quickRow)
        listOf(
            Triple("vehicle", R.drawable.ic_vehicle, R.string.q_vehicle),
            Triple("climate", R.drawable.ic_ac, R.string.q_climate),
            Triple("camera", R.drawable.ic_camera, R.string.q_camera),
            Triple("@carplay", R.drawable.ic_phone, R.string.app_carplay)
        ).forEachIndexed { i, (key, icon, label) ->
            val v = layoutInflater.inflate(R.layout.item_quick, row, false)
            v.findViewById<ImageView>(R.id.quickIcon).setImageResource(icon)
            v.findViewById<TextView>(R.id.quickLabel).setText(label)
            if (key == "@carplay") {
                v.setOnClickListener { openKnown(AppDefs.CARPLAY, null) }
                v.setOnLongClickListener { pick("app_" + AppDefs.CARPLAY.key); true }
            } else {
                v.setOnClickListener { openVehicle(key) }
                v.setOnLongClickListener { pick(key); true }
            }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            if (i > 0) lp.marginStart = Ui.dp(this, 10)
            row.addView(v, lp)
        }
    }

    private fun buildMediaChips() {
        val row = findViewById<LinearLayout>(R.id.mediaChips)
        listOf("music" to R.string.chip_media, "radio" to R.string.chip_radio, "media3" to R.string.chip_spotify)
            .forEachIndexed { i, (key, name) ->
                val tv = TextView(this).apply {
                    gravity = Gravity.CENTER
                    setBackgroundResource(R.drawable.bg_pill)
                    setTextColor(getColor(R.color.text))
                    textSize = 13f
                    maxLines = 1
                    tag = name
                    isClickable = true
                }
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                if (i > 0) lp.marginStart = Ui.dp(this, 6)
                bindApp(tv, key)
                row.addView(tv, lp)
                chipViews.add(tv)
            }
    }

    private fun refreshShortcuts() {
        val keys = listOf("music", "radio", "media3")
        chipViews.forEachIndexed { i, tv ->
            tv.text = AppUtils.label(this, Prefs.get(this, keys[i])) ?: getString(tv.tag as Int)
        }
        val nav = Prefs.get(this, "nav") ?: AppDefs.resolve(this, AppDefs.GMAPS)
        navApp.text = AppUtils.label(this, nav) ?: getString(R.string.app_gmaps)
        AppUtils.icon(this, nav)?.let { navAppIcon.setImageDrawable(it) }
    }

    private fun firstRunDefaults() {
        if (Prefs.get(this, "init6") != null) return
        val apps = AppUtils.launcherApps(this)
        fun find(vararg keys: String): String? =
            apps.firstOrNull { (label, _) -> keys.any { label.contains(it, ignoreCase = true) } }?.second
        fun keep(key: String, value: String?) { if (Prefs.get(this, key) == null && value != null) Prefs.put(this, key, value) }
        keep("music", find("music", "موسيقى", "音乐"))
        keep("radio", find("radio", "راديو", "收音机"))
        keep("media3", AppUtils.componentFor(this, "com.anghami") ?: AppUtils.componentFor(this, "com.spotify.music"))
        keep("phone", find("phone", "هاتف", "电话"))
        keep("vehicle", find("vehicle center", "vehicle", "مركز المركبة", "المركبة", "车辆", "car setting"))
        keep("climate", find("climate", "hvac", "air con", "مكيف", "تكييف", "空调"))
        keep("camera", find("avm", "360", "panoram", "全景", "camera", "الكاميرا"))
        Prefs.put(this, "init6", "1")
    }

    // =========================== opening things ===========================

    private fun bindApp(v: View, key: String) {
        v.setOnClickListener { launchOrPick(key) }
        v.setOnLongClickListener { pick(key); true }
    }

    private fun launchOrPick(key: String) {
        if (!AppUtils.launch(this, Prefs.get(this, key))) pick(key)
    }

    /** Known app: saved choice → installed app → its website → let the user pick. */
    private fun openKnown(app: KnownApp, overrideKey: String?) {
        val flat = overrideKey?.let { Prefs.get(this, it) } ?: AppDefs.resolve(this, app)
        if (AppUtils.launch(this, flat)) return
        val url = app.url
        if (url != null) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return
            } catch (_: Exception) {}
        }
        pick(overrideKey ?: ("app_" + app.key))
    }

    /** Car screens: the linked Changan screen, then Vehicle Center, then the dealer home screen. */
    private fun openVehicle(key: String) {
        if (AppUtils.launch(this, Prefs.get(this, key))) return
        if (key != "vehicle" && AppUtils.launch(this, Prefs.get(this, "vehicle"))) return
        Original.open(this)
    }

    private fun pick(key: String, title: Int = R.string.pick_app) {
        pendingKey = key
        pickApp.launch(Intent(this, AppsActivity::class.java)
            .putExtra(AppsActivity.EXTRA_PICK, true).putExtra(AppsActivity.EXTRA_TITLE, title))
    }

    private fun openSettingsAction(action: String) {
        try { startActivity(Intent(action)) } catch (_: Exception) { toast(R.string.cant_open) }
    }

    // =========================== quick panel ===========================

    private fun showQuickPanel() {
        val c = this
        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(c, 22), Ui.dp(c, 8), Ui.dp(c, 22), Ui.dp(c, 8))
        }
        fun label(res: Int) = TextView(c).apply {
            setText(res); textSize = 14f; setTextColor(getColor(R.color.text_dim))
            setPadding(0, Ui.dp(c, 14), 0, Ui.dp(c, 6))
        }
        // brightness
        root.addView(label(R.string.brightness))
        val seek = SeekBar(c).apply {
            max = 100
            val cur = if (Settings.System.canWrite(c))
                (Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 200) / 2.55f).roundToInt()
            else ((Prefs.brightness(c).takeIf { it >= 0 } ?: 0.8f) * 100).roundToInt()
            progress = cur
            progressTintList = ColorStateList.valueOf(Ui.accent(c))
            thumbTintList = progressTintList
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) setBrightness((p.coerceAtLeast(3)) / 100f)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(seek)
        if (!Settings.System.canWrite(c)) root.addView(TextView(c).apply {
            setText(R.string.brightness_limited); textSize = 12f; setTextColor(getColor(R.color.text_dim))
        })
        // theme
        root.addView(label(R.string.s_theme))
        val modes = intArrayOf(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM, AppCompatDelegate.MODE_NIGHT_NO, AppCompatDelegate.MODE_NIGHT_YES)
        root.addView(Ui.chips(c, listOf(getString(R.string.theme_auto), getString(R.string.theme_light), getString(R.string.theme_dark)),
            modes.indexOf(Prefs.nightMode(c))) { i ->
            Prefs.setNightMode(c, modes[i]); AppCompatDelegate.setDefaultNightMode(modes[i])
        })
        // colour
        root.addView(label(R.string.palette))
        root.addView(Ui.chips(c, Ui.paletteNames.map { getString(it) }, Ui.palettes.indexOf(Prefs.palette(c)), Ui.paletteDots) { i ->
            Prefs.put(c, "palette", Ui.palettes[i]); recreate()
        })
        // split screen + dealer screen
        val buttons = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, Ui.dp(c, 18), 0, 0) }
        fun action(icon: Int, text: Int, onClick: () -> Unit) = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setBackgroundResource(R.drawable.bg_card_alt); isClickable = true
            setPadding(Ui.dp(c, 12), Ui.dp(c, 14), Ui.dp(c, 12), Ui.dp(c, 14))
            addView(ImageView(c).apply { setImageResource(icon) }, LinearLayout.LayoutParams(Ui.dp(c, 26), Ui.dp(c, 26)))
            addView(TextView(c).apply { setText(text); textSize = 15f; setTextColor(getColor(R.color.text)); setPadding(Ui.dp(c, 8), 0, 0, 0) })
            setOnClickListener { onClick() }
        }
        val dialog = AlertDialog.Builder(c).setTitle(R.string.quick_title).setView(root).create()
        buttons.addView(action(R.drawable.ic_split, R.string.split_screen) { dialog.dismiss(); startSplit() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        buttons.addView(action(R.drawable.ic_changan, R.string.nav_changan) { dialog.dismiss(); Original.open(this) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = Ui.dp(c, 10) })
        root.addView(buttons)
        Ui.polish(root)
        dialog.show()
    }

    private fun startSplit() {
        if (SplitService.instance == null) { explainSplit(); return }
        splitFirst = null
        pick("@split1", R.string.split_pick_first)
    }

    private fun explainSplit() {
        AlertDialog.Builder(this)
            .setTitle(R.string.split_screen)
            .setMessage(R.string.split_need_service)
            .setPositiveButton(R.string.open_accessibility) { _, _ -> openSettingsAction(Settings.ACTION_ACCESSIBILITY_SETTINGS) }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    // =========================== weather (Hofuf) ===========================

    private fun maybeFetchWeather() {
        val now = System.currentTimeMillis()
        if (now - lastWeather < 30 * 60 * 1000L) return
        lastWeather = now
        Thread {
            try {
                val url = URL(String.format(Locale.US,
                    "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f" +
                        "&current=temperature_2m,weather_code,is_day" +
                        "&hourly=temperature_2m,weather_code&forecast_hours=12" +
                        "&daily=weather_code,temperature_2m_max,temperature_2m_min&forecast_days=4&timezone=Asia%%2FRiyadh",
                    HOFUF_LAT, HOFUF_LON))
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 8000; conn.readTimeout = 8000
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val json = JSONObject(body)
                weatherJson = json
                val cur = json.getJSONObject("current")
                val temp = cur.getDouble("temperature_2m").roundToInt()
                val code = cur.getInt("weather_code")
                val day = cur.optInt("is_day", 1) == 1
                runOnUiThread {
                    weatherTemp.text = getString(R.string.temp_format, temp)
                    weatherIcon.setImageResource(weatherIconFor(code, day))
                }
            } catch (_: Exception) {
                lastWeather = System.currentTimeMillis() - 25 * 60 * 1000L
            }
        }.start()
    }

    private fun showWeather() {
        val json = weatherJson
        if (json == null) { toast(R.string.w_loading); lastWeather = 0L; maybeFetchWeather(); return }
        val c = this
        val root = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(c, 22), Ui.dp(c, 6), Ui.dp(c, 22), Ui.dp(c, 6)) }
        val cur = json.getJSONObject("current")
        val daily = json.getJSONObject("daily")
        root.addView(TextView(c).apply {
            text = getString(R.string.temp_format, cur.getDouble("temperature_2m").roundToInt()) + "  " +
                getString(weatherText(cur.getInt("weather_code")))
            textSize = 26f; setTextColor(getColor(R.color.text))
        })
        root.addView(TextView(c).apply {
            text = getString(R.string.temp_hl, daily.getJSONArray("temperature_2m_max").getDouble(0).roundToInt(),
                daily.getJSONArray("temperature_2m_min").getDouble(0).roundToInt())
            textSize = 15f; setTextColor(getColor(R.color.text_dim))
        })
        fun section(res: Int) = TextView(c).apply {
            setText(res); textSize = 14f; setTextColor(getColor(R.color.text_dim)); setPadding(0, Ui.dp(c, 16), 0, Ui.dp(c, 6))
        }
        fun cell(top: String, icon: Int, bottom: String) = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(Ui.dp(c, 10), Ui.dp(c, 8), Ui.dp(c, 10), Ui.dp(c, 8))
            addView(TextView(c).apply { text = top; textSize = 13f; setTextColor(getColor(R.color.text_dim)); gravity = Gravity.CENTER })
            addView(ImageView(c).apply { setImageResource(icon) }, LinearLayout.LayoutParams(Ui.dp(c, 28), Ui.dp(c, 28)))
            addView(TextView(c).apply { text = bottom; textSize = 15f; setTextColor(getColor(R.color.text)); gravity = Gravity.CENTER })
        }
        root.addView(section(R.string.weather_hours))
        val hours = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        val hourly = json.getJSONObject("hourly")
        val ht = hourly.getJSONArray("time"); val htemp = hourly.getJSONArray("temperature_2m"); val hcode = hourly.getJSONArray("weather_code")
        for (i in 0 until minOf(ht.length(), 12) step 2) {
            val hour = ht.getString(i).substringAfter('T').take(5)
            hours.addView(cell(hour, weatherIconFor(hcode.getInt(i), hour < "18:00" && hour >= "06:00"),
                getString(R.string.temp_format, htemp.getDouble(i).roundToInt())))
        }
        root.addView(android.widget.HorizontalScrollView(c).apply { addView(hours) })
        root.addView(section(R.string.weather_days))
        val days = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        val dt = daily.getJSONArray("time")
        val dayFmt = SimpleDateFormat("EEE", Ui.locale(this))
        val parse = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        for (i in 1 until dt.length()) {
            val name = try { dayFmt.format(parse.parse(dt.getString(i)) ?: Date()) } catch (_: Exception) { dt.getString(i) }
            days.addView(cell(name, weatherIconFor(daily.getJSONArray("weather_code").getInt(i), true),
                getString(R.string.temp_hl, daily.getJSONArray("temperature_2m_max").getDouble(i).roundToInt(),
                    daily.getJSONArray("temperature_2m_min").getDouble(i).roundToInt())))
        }
        root.addView(android.widget.HorizontalScrollView(c).apply { addView(days) })
        Ui.polish(root)
        AlertDialog.Builder(c).setTitle(R.string.weather_title).setView(root).setPositiveButton(R.string.close, null).show()
    }

    private fun weatherText(code: Int): Int = when (code) {
        0 -> R.string.w_clear
        1, 2, 3 -> R.string.w_cloudy
        45, 48 -> R.string.w_fog
        in 51..67 -> R.string.w_rain
        in 71..77 -> R.string.w_snow
        in 80..86 -> R.string.w_showers
        in 95..99 -> R.string.w_storm
        else -> R.string.w_unknown
    }

    private fun weatherIconFor(code: Int, isDay: Boolean): Int = when (code) {
        0, 1 -> if (isDay) R.drawable.ic_sun else R.drawable.ic_moon
        in 51..67, in 80..86, in 95..99 -> R.drawable.ic_rain
        else -> R.drawable.ic_cloud
    }

    // =========================== climate (direct control only when the car allows it) ===========================

    private fun buildClimateGrid() {
        val row = findViewById<LinearLayout>(R.id.climateGrid)
        listOf(
            Triple(HV_AUTO, R.drawable.ic_auto, R.string.hv_auto), Triple(HV_AC, R.drawable.ic_ac, R.string.hv_ac),
            Triple(HV_RECIRC, R.drawable.ic_recirc, R.string.hv_recirc), Triple(HV_REAR, R.drawable.ic_defrost, R.string.hv_rear),
            Triple(HV_POWER, R.drawable.ic_power, R.string.hv_power)
        ).forEachIndexed { i, (action, icon, label) ->
            val v = layoutInflater.inflate(R.layout.item_hvac, row, false)
            v.findViewById<ImageView>(R.id.hvIcon).setImageResource(icon)
            v.findViewById<TextView>(R.id.hvLabel).setText(label)
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            if (i > 0) lp.marginStart = Ui.dp(this, 8)
            v.setOnClickListener { hvacAction(action) }
            row.addView(v, lp)
            hvacViews[action] = v
        }
    }

    private fun refreshClimate() {
        hvac = CarBridge.hvacAvailable()
        findViewById<TextView>(R.id.climateMode).setText(if (hvac) R.string.climate_direct else R.string.climate_opens)
        if (!hvac) {
            tempText.text = "--"; fanText.text = "--"
            hvacViews.values.forEach { it.isSelected = false }
            return
        }
        val power = CarBridge.bool(CarBridge.HVAC_POWER_ON)
        val temp = CarBridge.float(CarBridge.HVAC_TEMPERATURE_SET)
        val fan = CarBridge.int(CarBridge.HVAC_FAN_SPEED)
        tempText.text = temp?.let { String.format(Locale.US, "%.1f°", it) } ?: "--"
        fanText.text = fan?.toString() ?: "--"
        hvacViews[HV_AUTO]?.isSelected = CarBridge.bool(CarBridge.HVAC_AUTO_ON) == true
        hvacViews[HV_AC]?.isSelected = CarBridge.bool(CarBridge.HVAC_AC_ON) == true
        hvacViews[HV_RECIRC]?.isSelected = CarBridge.bool(CarBridge.HVAC_RECIRC_ON) == true
        hvacViews[HV_REAR]?.isSelected = CarBridge.rearDefrost() == true
        hvacViews[HV_POWER]?.isSelected = power == false
    }

    private fun hvacAction(action: Int) {
        if (action == HV_MORE || !hvac) { openVehicle("climate"); return }
        val ok = when (action) {
            HV_AUTO -> CarBridge.toggle(CarBridge.HVAC_AUTO_ON)
            HV_AC -> CarBridge.toggle(CarBridge.HVAC_AC_ON)
            HV_RECIRC -> CarBridge.toggle(CarBridge.HVAC_RECIRC_ON)
            HV_REAR -> CarBridge.toggleRearDefrost()
            HV_POWER -> CarBridge.toggle(CarBridge.HVAC_POWER_ON)
            else -> false
        }
        afterClimate(ok)
    }

    private fun stepTemp(delta: Float) {
        if (!hvac) { openVehicle("climate"); return }
        val t = CarBridge.float(CarBridge.HVAC_TEMPERATURE_SET)
        afterClimate(t != null && CarBridge.setFloat(CarBridge.HVAC_TEMPERATURE_SET, t + delta))
    }

    private fun stepFan(delta: Int) {
        if (!hvac) { openVehicle("climate"); return }
        val f = CarBridge.int(CarBridge.HVAC_FAN_SPEED)
        afterClimate(f != null && CarBridge.setInt(CarBridge.HVAC_FAN_SPEED, (f + delta).coerceAtLeast(0)))
    }

    private fun afterClimate(ok: Boolean) {
        if (!ok) { toast(R.string.climate_failed); openVehicle("climate") }
        refreshClimate()
    }

    // =========================== map (follows you) ===========================

    private fun isNight() =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private fun setupMap() {
        findViewById<View>(R.id.mapCard).clipToOutline = true
        map = findViewById(R.id.map)
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.isTilesScaledToDpi = true
        map.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        map.controller.setZoom(16.5)
        map.controller.setCenter(GeoPoint(HOFUF_LAT, HOFUF_LON))
        if (isNight()) map.overlayManager.tilesOverlay.setColorFilter(TilesOverlay.INVERTED_COLORS)
        findViewById<View>(R.id.btnRecenter).setOnClickListener {
            myLocation?.let { o -> o.enableFollowLocation(); o.myLocation?.let { p -> map.controller.animateTo(p) } }
        }
    }

    private fun startMapLocation() {
        if (!hasLocationPermission()) return
        val overlay = myLocation ?: MyLocationNewOverlay(GpsMyLocationProvider(this), map).also {
            map.overlays.add(it); myLocation = it
        }
        overlay.enableMyLocation()
        overlay.enableFollowLocation()
    }

    private fun maybeGeocode(lat: Double, lon: Double) {
        val now = System.currentTimeMillis()
        if (!Geocoder.isPresent() || now - lastGeocode < 3 * 60 * 1000L) return
        lastGeocode = now
        Thread {
            try {
                @Suppress("DEPRECATION")
                val a = Geocoder(this, Ui.locale(this)).getFromLocation(lat, lon, 1)?.firstOrNull()
                val name = a?.subLocality ?: a?.locality ?: a?.subAdminArea ?: a?.adminArea
                if (name != null) runOnUiThread { mapCity.text = name }
            } catch (_: Exception) { lastGeocode = System.currentTimeMillis() - 2 * 60 * 1000L }
        }.start()
    }

    // =========================== GPS ===========================

    private fun hasLocationPermission() =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            lastFixTime = System.currentTimeMillis()
            if (CarBridge.speedKmh() == null) showSpeed(if (location.hasSpeed()) (location.speed * 3.6f).roundToInt() else 0)
            maybeGeocode(location.latitude, location.longitude)
        }
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    @SuppressLint("MissingPermission")
    private fun startLocation() {
        if (!hasLocationPermission()) return
        startMapLocation()
        if (locationManager != null) return
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        locationManager = lm
        try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locationListener, Looper.getMainLooper()) } catch (_: Exception) {}
        val last = try { lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) } catch (_: Exception) { null }
        if (last != null) {
            maybeGeocode(last.latitude, last.longitude)
            map.controller.setCenter(GeoPoint(last.latitude, last.longitude))
        }
    }

    private fun stopLocation() {
        try { locationManager?.removeUpdates(locationListener) } catch (_: Exception) {}
        locationManager = null
        myLocation?.disableMyLocation()
    }

    // =========================== music (square cover, full) ===========================

    private fun roundArt() {
        mediaArt.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, Ui.dp(view.context, 18).toFloat())
            }
        }
        mediaArt.clipToOutline = true
        // keep the cover square: width follows the height
        mediaArt.addOnLayoutChangeListener { v, _, top, _, bottom, _, _, _, _ ->
            val h = bottom - top
            if (h > 0 && v.layoutParams.width != h) {
                v.layoutParams = v.layoutParams.apply { width = h }
            }
        }
    }

    private fun hasMediaAccess() = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list -> attachController(list?.firstOrNull()) }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = updateMedia()
        override fun onPlaybackStateChanged(state: PlaybackState?) = updateMedia()
        override fun onSessionDestroyed() = attachController(null)
    }

    private fun startMedia() {
        if (!hasMediaAccess()) { updateMedia(); return }
        try {
            val msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            val cn = ComponentName(this, MediaListener::class.java)
            msm.addOnActiveSessionsChangedListener(sessionsListener, cn)
            sessionManager = msm
            attachController(msm.getActiveSessions(cn).firstOrNull())
        } catch (_: Exception) { updateMedia() }
    }

    private fun stopMedia() {
        try { sessionManager?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Exception) {}
        sessionManager = null
        controller?.unregisterCallback(controllerCallback)
        controller = null
    }

    private fun attachController(c: MediaController?) {
        controller?.unregisterCallback(controllerCallback)
        controller = c
        c?.registerCallback(controllerCallback, handler)
        updateMedia()
    }

    private fun updateMedia() {
        val c = controller
        val md = c?.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
        if (c == null || title.isNullOrBlank()) {
            mediaSource.setText(R.string.now_playing)
            mediaTitle.setText(if (hasMediaAccess()) R.string.media_idle else R.string.media_enable)
            mediaArtist.text = ""
        } else {
            mediaSource.text = getString(R.string.now_playing_from, AppUtils.appLabel(this, c.packageName))
            mediaTitle.text = title
            mediaArtist.text = artist ?: ""
        }
        // the biggest picture the player offers
        val art: Bitmap? = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (art != null) {
            mediaArt.setPadding(0, 0, 0, 0)
            mediaArt.scaleType = ImageView.ScaleType.CENTER_CROP
            mediaArt.setImageBitmap(art)
        } else {
            val p = Ui.dp(this, 28)
            mediaArt.setPadding(p, p, p, p)
            mediaArt.scaleType = ImageView.ScaleType.FIT_CENTER
            mediaArt.setImageResource(R.drawable.ic_music)
        }
        val playing = c?.playbackState?.state == PlaybackState.STATE_PLAYING
        btnPlay.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        updateProgress()
    }

    private fun updateProgress() {
        val c = controller
        val duration = c?.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val st = c?.playbackState
        if (c == null || st == null || duration <= 0L) {
            mediaProgress.progress = 0; mediaPos.text = ""; mediaDur.text = ""; return
        }
        var pos = st.position
        if (st.state == PlaybackState.STATE_PLAYING) pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        pos = pos.coerceIn(0L, duration)
        mediaProgress.progress = (pos * 1000 / duration).toInt()
        mediaPos.text = time(pos)
        mediaDur.text = time(duration)
    }

    private fun time(ms: Long): String { val s = ms / 1000; return String.format(Locale.US, "%d:%02d", s / 60, s % 60) }

    private fun media(keyCode: Int) {
        val c = controller
        if (c != null) {
            val t = c.transportControls
            when (keyCode) {
                KeyEvent.KEYCODE_MEDIA_NEXT -> t.skipToNext()
                KeyEvent.KEYCODE_MEDIA_PREVIOUS -> t.skipToPrevious()
                else -> if (c.playbackState?.state == PlaybackState.STATE_PLAYING) t.pause() else t.play()
            }
        } else {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        }
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()
}
