package com.fahad.eadolauncher

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Every screen: fits the Eado Plus 13.2" screen, uses the chosen colour theme,
 * the clear font, the smooth touch, English, and the brightness setting.
 */
open class BaseActivity : AppCompatActivity() {

    protected var appliedUiWidth = 0
    private var appliedPalette = ""

    override fun attachBaseContext(newBase: Context) {
        val dm = newBase.resources.displayMetrics
        val target = Prefs.uiWidth(newBase)
        appliedUiWidth = target
        val shortSide = minOf(dm.widthPixels, dm.heightPixels)
        val density = max(100, (shortSide * 160f / target).roundToInt())
        val cfg = Configuration(newBase.resources.configuration)
        cfg.densityDpi = density
        cfg.screenWidthDp = (dm.widthPixels * 160f / density).roundToInt()
        cfg.screenHeightDp = (dm.heightPixels * 160f / density).roundToInt()
        cfg.smallestScreenWidthDp = minOf(cfg.screenWidthDp, cfg.screenHeightDp)
        super.attachBaseContext(newBase.createConfigurationContext(cfg))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        appliedPalette = Prefs.palette(this)
        setTheme(Ui.themeFor(appliedPalette))
        super.onCreate(savedInstanceState)
        // the launcher is in English
        if (Prefs.get(this, "lang_en") == null) {
            Prefs.put(this, "lang_en", "1")
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("en"))
        }
    }

    override fun setContentView(layoutResID: Int) {
        super.setContentView(layoutResID)
        Ui.polish(window.decorView)
    }

    override fun onResume() {
        super.onResume()
        if ((appliedUiWidth != 0 && appliedUiWidth != Prefs.uiWidth(this)) || appliedPalette != Prefs.palette(this)) {
            recreate(); return
        }
        applyBrightness()
    }

    /** Without the system permission, the chosen brightness applies to the launcher's own screens. */
    fun applyBrightness() {
        val b = Prefs.brightness(this)
        val lp = window.attributes
        lp.screenBrightness = if (b >= 0f && !Settings.System.canWrite(this)) b.coerceIn(0.05f, 1f) else -1f
        window.attributes = lp
    }

    fun setBrightness(v: Float) {
        Prefs.setBrightness(this, v)
        if (Settings.System.canWrite(this)) {
            try {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS,
                    (v * 255).roundToInt().coerceIn(5, 255))
            } catch (_: Exception) {}
        }
        applyBrightness()
    }

    fun setLanguage(tag: String) {
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
    }

    fun currentLanguage(): String =
        AppCompatDelegate.getApplicationLocales()[0]?.language ?: "ar"
}
