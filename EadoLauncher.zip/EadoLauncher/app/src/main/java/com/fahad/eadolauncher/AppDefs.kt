package com.fahad.eadolauncher

import android.content.Context

/** The apps the launcher knows by name, found by package or by label. */
data class KnownApp(
    val key: String,
    val name: Int,
    val packages: List<String>,
    val labels: List<String>,
    val url: String? = null
)

object AppDefs {
    val CARPLAY = KnownApp("dock0", R.string.app_carplay, emptyList(), listOf("carplay", "car play", "كاربلاي"))
    val GMAPS = KnownApp("gmaps", R.string.app_gmaps, listOf("com.google.android.apps.maps"),
        listOf("google maps", "خرائط google", "قوقل ماب"), "https://maps.google.com")
    val YOUTUBE = KnownApp("youtube", R.string.app_youtube, listOf("com.google.android.youtube", "com.google.android.apps.automotive.youtube", "com.google.android.youtube.tv"),
        listOf("youtube", "يوتيوب"), "https://m.youtube.com")
    val NETFLIX = KnownApp("netflix", R.string.app_netflix, listOf("com.netflix.mediaclient"), listOf("netflix", "نتفليكس", "نتفلكس"),
        "https://www.netflix.com")
    val TIKTOK = KnownApp("tiktok", R.string.app_tiktok, listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
        listOf("tiktok", "تيك توك"), "https://www.tiktok.com")
    val THMANYAH = KnownApp("thmanyah", R.string.app_thmanyah, emptyList(), listOf("thmanyah", "ثمانية"), "https://thmanyah.com")
    val IPTV = KnownApp("iptv", R.string.app_iptv, listOf("ar.tvplayer.tv", "com.nst.iptvsmarterstvbox"),
        listOf("tivimate", "iptv", "smarters"))
    val HUDHUD = KnownApp("hudhud", R.string.app_hudhud, listOf("sa.hudhud.maps"), listOf("hudhud", "هدهد"), "https://hudhud.sa")
    val DISNEY = KnownApp("disney", R.string.app_disney, listOf("com.disney.disneyplus"), listOf("disney", "ديزني"),
        "https://www.disneyplus.com")
    val OSN = KnownApp("osn", R.string.app_osn, emptyList(), listOf("osn"), "https://www.osnplus.com")

    /** Shortcuts that can be re-linked from Settings. */
    val dock = listOf(CARPLAY)

    /** The Apps screen: only the apps Fahad uses. */
    val entertainment = listOf(YOUTUBE, GMAPS, HUDHUD)

    /** Saved choice, else the installed app found by package, else by label. */
    fun resolve(c: Context, app: KnownApp): String? {
        Prefs.get(c, "app_" + app.key)?.let { return it }
        app.packages.firstNotNullOfOrNull { AppUtils.componentFor(c, it) }?.let { return it }
        if (app.labels.isEmpty()) return null
        return installed(c).firstOrNull { (label, _) ->
            app.labels.any { label.contains(it, ignoreCase = true) }
        }?.second
    }

    // the app list is read once every few seconds, so the screens stay smooth
    private var cache: List<Pair<String, String>> = emptyList()
    private var cacheTime = 0L
    private fun installed(c: Context): List<Pair<String, String>> {
        val now = System.currentTimeMillis()
        if (now - cacheTime > 5000) { cache = AppUtils.launcherApps(c); cacheTime = now }
        return cache
    }

    fun hasGoogleServices(c: Context): Boolean = try {
        @Suppress("DEPRECATION") c.packageManager.getPackageInfo("com.google.android.gms", 0); true
    } catch (_: Exception) { false }
}
