package com.fahad.eadolauncher

import android.content.ComponentName
import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class AppsActivity : BaseActivity() {

    companion object {
        const val EXTRA_PICK = "pick"
        const val EXTRA_RESULT = "component"
        const val EXTRA_TITLE = "title"
    }

    private data class AppEntry(val label: String, val component: ComponentName, val icon: Drawable)

    private var pickMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apps)
        pickMode = intent.getBooleanExtra(EXTRA_PICK, false)

        val title = intent.getIntExtra(EXTRA_TITLE, 0)
        findViewById<TextView>(R.id.appsTitle)
            .setText(if (title != 0) title else if (pickMode) R.string.pick_app else R.string.all_apps)
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }

        val list = findViewById<RecyclerView>(R.id.appsList)
        list.layoutManager = GridLayoutManager(this, 4)

        Thread {
            val pm = packageManager
            val apps = pm.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
            )
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    AppEntry(
                        it.loadLabel(pm).toString(),
                        ComponentName(it.activityInfo.packageName, it.activityInfo.name),
                        it.loadIcon(pm)
                    )
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread { if (!isFinishing) list.adapter = Adapter(apps) }
        }.start()
    }

    private fun onPicked(e: AppEntry) {
        if (pickMode) {
            setResult(RESULT_OK, Intent().putExtra(EXTRA_RESULT, e.component.flattenToString()))
            finish()
        } else if (!AppUtils.launch(this, e.component.flattenToString())) {
            Toast.makeText(this, R.string.cant_open, Toast.LENGTH_SHORT).show()
        }
    }

    private fun openInfo(e: AppEntry) {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:" + e.component.packageName))
            )
        } catch (_: Exception) {}
    }

    private inner class Adapter(val items: List<AppEntry>) : RecyclerView.Adapter<Holder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val v = layoutInflater.inflate(R.layout.item_app, parent, false)
            v.isClickable = true
            Ui.polish(v)
            return Holder(v)
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: Holder, position: Int) {
            val e = items[position]
            h.icon.setImageDrawable(e.icon)
            h.label.text = e.label
            h.itemView.setOnClickListener { onPicked(e) }
            h.itemView.setOnLongClickListener { if (!pickMode) openInfo(e); true }
        }
    }

    private class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.appIcon)
        val label: TextView = v.findViewById(R.id.appLabel)
    }
}
