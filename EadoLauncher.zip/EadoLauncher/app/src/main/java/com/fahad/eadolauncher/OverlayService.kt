package com.fahad.eadolauncher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

/**
 * The hidden button: an invisible strip in the middle of the left edge.
 * Double-tap it from anywhere (even the dealer screen) to come back to the launcher.
 */
class OverlayService : Service() {

    companion object {
        fun start(c: Context) {
            if (!Prefs.hotspot(c) || !Settings.canDrawOverlays(c)) return
            val i = Intent(c, OverlayService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
            } catch (_: Exception) {}
        }

        fun stop(c: Context) = c.stopService(Intent(c, OverlayService::class.java))
    }

    private var view: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        addHotspot()
        return START_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("hotspot", getString(R.string.overlay_channel),
                NotificationManager.IMPORTANCE_MIN))
            Notification.Builder(this, "hotspot")
        } else {
            @Suppress("DEPRECATION") Notification.Builder(this)
        }
        val n = builder.setSmallIcon(R.drawable.ic_launcher).setContentTitle(getString(R.string.overlay_text)).build()
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(7, n)
        } catch (_: Exception) {}
    }

    private fun addHotspot() {
        if (view != null || !Settings.canDrawOverlays(this)) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            (22 * d).toInt(), (150 * d).toInt(), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL }

        val v = View(this)
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onDoubleTap(e: MotionEvent): Boolean {
                v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                startActivity(Intent(this@OverlayService, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
                return true
            }
        })
        v.setOnTouchListener { _, e -> detector.onTouchEvent(e) }
        try {
            wm.addView(v, lp)
            view = v
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        view?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {} }
        view = null
        super.onDestroy()
    }
}
