package com.fahad.eadolauncher

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import kotlin.math.roundToInt

/** Apps: YouTube, Google Maps, Hudhud Maps. */
class EntertainmentActivity : BaseActivity() {

    private val apps = AppDefs.entertainment
    private val tileViews = mutableListOf<View>()
    private lateinit var lockOverlay: View
    private lateinit var lockSpeed: TextView
    private lateinit var status: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var locationManager: LocationManager? = null
    private var lastFixTime = 0L
    private var locked = false

    private var pendingKey: String? = null
    private val pickApp = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val key = pendingKey ?: return@registerForActivityResult
        pendingKey = null
        if (res.resultCode == RESULT_OK) {
            Prefs.put(this, key, res.data?.getStringExtra(AppsActivity.EXTRA_RESULT))
            refresh()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_entertainment)
        pendingKey = savedInstanceState?.getString("pendingKey")
        lockOverlay = findViewById(R.id.lockOverlay)
        lockSpeed = findViewById(R.id.lockSpeed)
        status = findViewById(R.id.entStatus)
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        CarBridge.connect(this)
        buildGrid()
        Ui.polish(window.decorView)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("pendingKey", pendingKey)
    }

    override fun onResume() {
        super.onResume()
        refresh()
        NetUtils.bindChip(this)
        setLocked(false, null)
        if (Prefs.lockFun(this)) startLocation()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        try { locationManager?.removeUpdates(listener) } catch (_: Exception) {}
        locationManager = null
        handler.removeCallbacks(tick)
    }

    private fun buildGrid() {
        val grid = findViewById<LinearLayout>(R.id.entGrid)
        apps.chunked(3).forEachIndexed { r, rowApps ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val rowLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            if (r > 0) rowLp.topMargin = Ui.dp(this, 14)
            grid.addView(row, rowLp)
            rowApps.forEachIndexed { c, app ->
                val v = layoutInflater.inflate(R.layout.item_ent, row, false)
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                if (c > 0) lp.marginStart = Ui.dp(this, 14)
                v.setOnClickListener { open(app) }
                v.setOnLongClickListener { pick("app_" + app.key); true }
                row.addView(v, lp)
                tileViews.add(v)
            }
        }
        // keep tiles a comfortable size when there are only a few apps
        val rows = (apps.size + 2) / 3
        if (rows < 3) grid.addView(View(this), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, (3 - rows).toFloat()))
    }

    private fun refresh() {
        apps.forEachIndexed { i, app ->
            val v = tileViews.getOrNull(i) ?: return@forEachIndexed
            val icon = v.findViewById<ImageView>(R.id.entIcon)
            val label = v.findViewById<TextView>(R.id.entLabel)
            val sub = v.findViewById<TextView>(R.id.entSub)
            val flat = AppDefs.resolve(this, app)
            val d = AppUtils.icon(this, flat)
            if (d != null) {
                icon.setImageDrawable(d); icon.alpha = 1f
                label.text = AppUtils.label(this, flat) ?: getString(app.name)
                sub.text = ""
            } else {
                icon.setImageResource(if (app.url != null) R.drawable.ic_web else R.drawable.ic_apps_dim)
                icon.alpha = 0.7f
                label.setText(app.name)
                sub.setText(if (app.url != null) R.string.opens_web else R.string.not_installed)
            }
        }
    }

    private fun open(app: KnownApp) {
        if (locked) return
        if (AppUtils.launch(this, AppDefs.resolve(this, app))) return
        val url = app.url
        if (url != null) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Exception) {}
        }
        pick("app_" + app.key)
    }

    private fun pick(key: String) {
        pendingKey = key
        pickApp.launch(Intent(this, AppsActivity::class.java).putExtra(AppsActivity.EXTRA_PICK, true))
    }

    // ---------- optional drive lock (off unless turned on in Settings) ----------

    private fun setLocked(value: Boolean, kmh: Int?) {
        locked = value
        lockOverlay.visibility = if (value) View.VISIBLE else View.GONE
        status.setText(if (value) R.string.ent_moving else R.string.ent_parked)
        lockSpeed.text = kmh?.toString() ?: "--"
    }

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            lastFixTime = System.currentTimeMillis()
            if (CarBridge.speedKmh() != null) return
            val kmh = if (location.hasSpeed()) (location.speed * 3.6f).roundToInt() else 0
            setLocked(Prefs.lockFun(this@EntertainmentActivity) && kmh > 5, kmh)
        }
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    private val tick = object : Runnable {
        override fun run() {
            NetUtils.bindChip(this@EntertainmentActivity)
            if (Prefs.lockFun(this@EntertainmentActivity)) {
                val carSpeed = CarBridge.speedKmh()
                if (carSpeed != null) { lastFixTime = System.currentTimeMillis(); setLocked(carSpeed > 5, carSpeed) }
                else if (locked && System.currentTimeMillis() - lastFixTime > 30_000) setLocked(false, null)
            }
            handler.postDelayed(this, 1000)
        }
    }

    @SuppressLint("MissingPermission")
    private fun startLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        locationManager = lm
        try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper()) } catch (_: Exception) {}
    }
}
