package com.fahad.eadolauncher

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.provider.Settings
import android.widget.ImageView
import android.widget.TextView

object NetUtils {

    fun isOnline(c: Context): Boolean = try {
        val cm = c.getSystemService(ConnectivityManager::class.java)
        val caps = cm?.activeNetwork?.let { cm.getNetworkCapabilities(it) }
        caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    } catch (_: Exception) {
        false
    }

    /** Shows connected / not connected on the chip; tapping it opens Wi-Fi settings (for the phone hotspot). */
    fun bindChip(a: Activity) {
        val chip = a.findViewById<android.view.View>(R.id.netChip) ?: return
        val online = isOnline(a)
        a.findViewById<TextView>(R.id.netText).setText(if (online) R.string.net_on else R.string.net_off)
        a.findViewById<ImageView>(R.id.netIcon).imageTintList =
            ColorStateList.valueOf(if (online) Ui.accent(a) else a.getColor(R.color.text_dim))
        chip.setOnClickListener {
            try { a.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) } catch (_: Exception) {}
        }
    }
}
