package com.fahad.eadolauncher

import android.service.notification.NotificationListenerService

/** Only exists so the launcher may read what is playing (title, artist). */
class MediaListener : NotificationListenerService()
