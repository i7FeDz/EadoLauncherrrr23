package com.fahad.eadolauncher

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/**
 * Split screen: opens the first app, asks Android to split, then opens the second app beside it.
 * Works only if the head unit supports split screen.
 */
class SplitService : AccessibilityService() {

    companion object {
        var instance: SplitService? = null
            private set

        /** false = the service isn't turned on yet */
        fun run(first: String, second: String): Boolean {
            val s = instance ?: return false
            s.split(first, second)
            return true
        }
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun split(first: String, second: String) {
        val h = Handler(Looper.getMainLooper())
        AppUtils.launch(this, first)
        h.postDelayed({
            @Suppress("DEPRECATION")
            performGlobalAction(GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)
        }, 900)
        h.postDelayed({
            val cn = ComponentName.unflattenFromString(second) ?: return@postDelayed
            try {
                startActivity(Intent(Intent.ACTION_MAIN).setComponent(cn).addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK))
            } catch (_: Exception) {}
        }, 1900)
    }
}
