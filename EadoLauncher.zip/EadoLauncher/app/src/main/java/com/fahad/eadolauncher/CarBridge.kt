package com.fahad.eadolauncher

import android.content.Context
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Talks to the car through the standard Android car interface (android.car), if the head unit has it.
 * Everything is optional: when the unit doesn't expose it, every call returns null/false and the
 * launcher falls back to GPS speed and to opening the Changan screens.
 */
object CarBridge {
    const val PERF_VEHICLE_SPEED = 291504647
    const val GEAR_SELECTION = 289408000
    const val CURRENT_GEAR = 289408001
    const val HVAC_POWER_ON = 354419984
    const val HVAC_AC_ON = 354419973
    const val HVAC_AUTO_ON = 354419978
    const val HVAC_RECIRC_ON = 354419976
    const val HVAC_FAN_SPEED = 356517120
    const val HVAC_TEMPERATURE_SET = 358614275
    const val HVAC_DEFROSTER = 320865540
    const val TURN_SIGNAL_STATE = 289408008
    const val HAZARD_LIGHTS_STATE = 289410563
    const val HEADLIGHTS_STATE = 289410560
    private const val WINDOW_REAR = 2

    private var manager: Any? = null
    private var tried = false
    private val INT = Int::class.javaPrimitiveType
    private val BOOL = Boolean::class.javaPrimitiveType
    private val FLOAT = Float::class.javaPrimitiveType

    fun connect(c: Context): Boolean {
        if (manager != null) return true
        if (tried) return false
        tried = true
        manager = try {
            val carCls = Class.forName("android.car.Car")
            val car = carCls.getMethod("createCar", Context::class.java).invoke(null, c.applicationContext)
            car?.let { carCls.getMethod("getCarManager", String::class.java).invoke(it, "property") }
        } catch (t: Throwable) {
            null
        }
        return manager != null
    }

    /** Call after a permission is granted so the next connect() tries again. */
    fun reset() {
        if (manager == null) tried = false
    }

    val connected get() = manager != null

    fun areas(prop: Int): IntArray? = try {
        val m = manager
        val cfg = m?.javaClass?.getMethod("getCarPropertyConfig", INT)?.invoke(m, prop)
        cfg?.javaClass?.getMethod("getAreaIds")?.invoke(cfg) as? IntArray
    } catch (t: Throwable) {
        null
    }

    fun has(prop: Int) = areas(prop) != null

    private fun firstArea(prop: Int): Int = areas(prop)?.firstOrNull() ?: 0

    private fun read(method: String, prop: Int, area: Int): Any? = try {
        val m = manager
        m?.javaClass?.getMethod(method, INT, INT)?.invoke(m, prop, area)
    } catch (t: Throwable) {
        null
    }

    private fun write(method: String, type: Class<*>?, prop: Int, area: Int, value: Any): Boolean = try {
        val m = manager ?: throw IllegalStateException()
        m.javaClass.getMethod(method, INT, INT, type).invoke(m, prop, area, value)
        true
    } catch (t: Throwable) {
        false
    }

    fun float(prop: Int) = read("getFloatProperty", prop, firstArea(prop)) as? Float
    fun int(prop: Int) = read("getIntProperty", prop, firstArea(prop)) as? Int
    fun bool(prop: Int) = read("getBooleanProperty", prop, firstArea(prop)) as? Boolean

    fun setBool(prop: Int, v: Boolean) = write("setBooleanProperty", BOOL, prop, firstArea(prop), v)
    fun setInt(prop: Int, v: Int) = write("setIntProperty", INT, prop, firstArea(prop), v)
    fun setFloat(prop: Int, v: Float) = write("setFloatProperty", FLOAT, prop, firstArea(prop), v)

    fun toggle(prop: Int): Boolean = bool(prop)?.let { setBool(prop, !it) } ?: false

    // ---- rear window defroster uses the window area, not the first one ----
    private fun rearArea(): Int? = areas(HVAC_DEFROSTER)?.let { a -> a.firstOrNull { it and WINDOW_REAR != 0 } }

    fun rearDefrost(): Boolean? = rearArea()?.let { read("getBooleanProperty", HVAC_DEFROSTER, it) as? Boolean }

    fun toggleRearDefrost(): Boolean {
        val area = rearArea() ?: return false
        val cur = read("getBooleanProperty", HVAC_DEFROSTER, area) as? Boolean ?: return false
        return write("setBooleanProperty", BOOL, HVAC_DEFROSTER, area, !cur)
    }

    // ---- helpers ----
    fun speedKmh(): Int? = float(PERF_VEHICLE_SPEED)?.let { (abs(it) * 3.6f).roundToInt() }

    fun gearLetter(): String? {
        val g = int(GEAR_SELECTION) ?: int(CURRENT_GEAR) ?: return null
        return when (g) {
            1 -> "N"
            2 -> "R"
            4 -> "P"
            8 -> "D"
            else -> if (g >= 16) "M" else null
        }
    }

    /** 0 none, 1 right, 2 left — null when the car doesn't share it. */
    fun turnSignal(): Int? = int(TURN_SIGNAL_STATE)
    fun hazard(): Boolean? = int(HAZARD_LIGHTS_STATE)?.let { it == 1 }
    fun headlights(): Boolean? = int(HEADLIGHTS_STATE)?.let { it == 1 }

    fun hvacAvailable(): Boolean = connected && (bool(HVAC_POWER_ON) != null || bool(HVAC_AC_ON) != null)
}
