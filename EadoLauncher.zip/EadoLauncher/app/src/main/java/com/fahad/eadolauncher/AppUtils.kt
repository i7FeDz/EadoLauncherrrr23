package com.fahad.eadolauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable

object AppUtils {

    fun flat(info: ResolveInfo): String =
        ComponentName(info.activityInfo.packageName, info.activityInfo.name).flattenToString()

    fun launch(c: Context, flat: String?): Boolean {
        val cn = flat?.let { ComponentName.unflattenFromString(it) } ?: return false
        return try {
            c.startActivity(
                Intent(Intent.ACTION_MAIN)
                    .setComponent(cn)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
            true
        } catch (e: Exception) {
            false
        }
    }

    fun launchPackage(c: Context, pkg: String): Boolean {
        val i = c.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return try {
            c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
        } catch (e: Exception) {
            false
        }
    }

    fun componentFor(c: Context, pkg: String): String? =
        c.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToString()

    fun label(c: Context, flat: String?): String? {
        val cn = flat?.let { ComponentName.unflattenFromString(it) } ?: return null
        return try {
            c.packageManager.getActivityInfo(cn, 0).loadLabel(c.packageManager).toString()
        } catch (e: Exception) {
            null
        }
    }

    fun appLabel(c: Context, pkg: String): String = try {
        c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    fun icon(c: Context, flat: String?): Drawable? {
        val cn = flat?.let { ComponentName.unflattenFromString(it) } ?: return null
        return try {
            c.packageManager.getActivityIcon(cn)
        } catch (e: Exception) {
            null
        }
    }

    /** All apps that show in an app drawer, as (label, component). */
    fun launcherApps(c: Context): List<Pair<String, String>> {
        val pm = c.packageManager
        return pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
            .filter { it.activityInfo.packageName != c.packageName }
            .map { it.loadLabel(pm).toString() to flat(it) }
    }

    /** Other home screens on the unit, e.g. the original Changan system. */
    fun homeApps(c: Context): List<ResolveInfo> =
        c.packageManager.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
        ).filter {
            it.activityInfo.packageName != c.packageName &&
                it.activityInfo.packageName != "com.android.settings"
        }
}
