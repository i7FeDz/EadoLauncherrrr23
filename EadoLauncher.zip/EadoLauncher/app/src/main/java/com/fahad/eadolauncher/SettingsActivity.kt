package com.fahad.eadolauncher

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Resources
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.DisplayMetrics
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.NotificationManagerCompat

class SettingsActivity : BaseActivity() {

    private lateinit var root: LinearLayout
    private val uiWidths = intArrayOf(980, 860, 740)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        root = findViewById(R.id.settingsRoot)
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        build()  // statuses may have changed after visiting system settings
    }

    private fun build() {
        root.removeAllViews()
        val c = this

        card(R.string.s_profile).apply {
            addView(label(R.string.s_owner_name))
            addView(EditText(c).apply {
                setText(Prefs.name(c)); textSize = 17f; setTextColor(getColor(R.color.text)); setSingleLine()
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, d: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, d: Int) {}
                    override fun afterTextChanged(s: Editable?) { Prefs.put(c, "name", s?.toString()) }
                })
            })
        }

        card(R.string.s_display).apply {
            addView(label(R.string.language))
            addView(Ui.chips(c, listOf(getString(R.string.lang_ar), getString(R.string.lang_en)),
                if (currentLanguage() == "en") 1 else 0) { i -> setLanguage(if (i == 1) "en" else "ar") })
            addView(label(R.string.s_theme))
            val modes = intArrayOf(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM, AppCompatDelegate.MODE_NIGHT_NO, AppCompatDelegate.MODE_NIGHT_YES)
            addView(Ui.chips(c, listOf(getString(R.string.theme_auto), getString(R.string.theme_light), getString(R.string.theme_dark)),
                modes.indexOf(Prefs.nightMode(c))) { i -> Prefs.setNightMode(c, modes[i]); AppCompatDelegate.setDefaultNightMode(modes[i]) })
            addView(label(R.string.palette))
            addView(Ui.chips(c, Ui.paletteNames.map { getString(it) }, Ui.palettes.indexOf(Prefs.palette(c)), Ui.paletteDots) { i ->
                Prefs.put(c, "palette", Ui.palettes[i]); recreate()
            })
            addView(label(R.string.s_ui_size))
            addView(Ui.chips(c, listOf(getString(R.string.s_ui_small), getString(R.string.s_ui_medium), getString(R.string.s_ui_large)),
                uiWidths.indexOf(Prefs.uiWidth(c))) { i -> Prefs.setUiWidth(c, uiWidths[i]); recreate() })
            addView(hint(getString(R.string.s_ui_hint)))
        }

        card(R.string.s_launcher).apply {
            addView(switchRow(R.string.s_hotspot_title, R.string.s_hotspot_hint, Prefs.hotspot(c)) { on ->
                Prefs.setHotspot(c, on)
                if (on) {
                    if (!Settings.canDrawOverlays(c)) openSettings(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, true)
                    OverlayService.start(c)
                } else OverlayService.stop(c)
            })
            addView(switchRow(R.string.s_lock_title, R.string.s_lock_hint, Prefs.lockFun(c)) { on -> Prefs.setLockFun(c, on) })
            addView(row(getString(R.string.set_open_original)) { Original.open(c) })
            addView(row(getString(R.string.set_change_original)) { Original.open(c, true) })
            addView(row(getString(R.string.set_default_home)) { openSettings(Settings.ACTION_HOME_SETTINGS) })
            addView(row(getString(R.string.set_system)) { openSettings(Settings.ACTION_SETTINGS) })
            addView(row(getString(R.string.s_reset)) {
                Prefs.remove(c, "init6", "nav", "music", "radio", "media3", "phone", "climate", "drive", "vehicle",
                    "autohold", "camera", *AppDefs.entertainment.map { "app_" + it.key }.toTypedArray(),
                    *AppDefs.dock.map { "app_" + it.key }.toTypedArray())
                Toast.makeText(c, R.string.s_reset_done, Toast.LENGTH_SHORT).show()
            })
        }

        // what is ready on this screen, and a one-tap way to fix what isn't
        card(R.string.s_status).apply {
            fun st(ok: Boolean) = getString(if (ok) R.string.st_ok else R.string.st_missing)
            val gms = AppDefs.hasGoogleServices(c)
            addView(info(getString(R.string.s_status_line, getString(R.string.st_gms), getString(if (gms) R.string.st_ok else R.string.st_absent))))
            addView(row(getString(R.string.s_status_line, getString(R.string.st_overlay), st(Settings.canDrawOverlays(c)))) {
                openSettings(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, true)
            })
            addView(row(getString(R.string.s_status_line, getString(R.string.st_access), st(SplitService.instance != null))) {
                openSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            })
            addView(row(getString(R.string.s_status_line, getString(R.string.st_notif),
                st(NotificationManagerCompat.getEnabledListenerPackages(c).contains(packageName)))) {
                openSettings("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
            })
            addView(row(getString(R.string.s_status_line, getString(R.string.st_bright), st(Settings.System.canWrite(c)))) {
                openSettings(Settings.ACTION_MANAGE_WRITE_SETTINGS, true)
            })
        }

        card(R.string.s_about).apply {
            val version = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Exception) { "?" }
            addView(info(getString(R.string.s_version, version)))
            val real = DisplayMetrics()
            @Suppress("DEPRECATION") windowManager.defaultDisplay.getRealMetrics(real)
            addView(info(getString(R.string.s_screen, real.widthPixels, real.heightPixels, Resources.getSystem().displayMetrics.densityDpi)))
            addView(info(getString(R.string.s_android, Build.VERSION.RELEASE)))
            val car = CarBridge.connect(c)
            addView(info(getString(if (car) R.string.s_car_api_yes else R.string.s_car_api_no)))
            if (car) {
                fun yn(b: Boolean) = getString(if (b) R.string.yes else R.string.no)
                addView(info(getString(R.string.s_car_props, yn(CarBridge.speedKmh() != null), yn(CarBridge.gearLetter() != null), yn(CarBridge.hvacAvailable()))))
            }
            addView(label(R.string.s_system_apps))
            addView(hint(getString(R.string.s_system_apps_hint)))
            val list = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
            list.addView(hint(getString(R.string.s_loading)))
            addView(list)
            loadSystemScreens(list)
        }
        Ui.polish(root)
    }

    /** Screens of the car's own apps, so AUTO HOLD / climate / drive mode can be linked exactly. */
    private fun loadSystemScreens(list: LinearLayout) {
        Thread {
            val pm = packageManager
            val keys = listOf("changan", "vehicle", "hvac", "climate", "aircon", "carsetting", "car.", ".car", "setting",
                "launcher", "radio", "drive", "avm", "dvr", "camera", "carplay", "link")
            val found = mutableListOf<Pair<String, ComponentName>>()
            try {
                @Suppress("DEPRECATION")
                val all = pm.getInstalledApplications(0)
                    .filter { a -> a.packageName != packageName && keys.any { a.packageName.contains(it, true) } }
                    .sortedBy { it.packageName }
                for (a in all) {
                    val appLabel = a.loadLabel(pm).toString()
                    val acts = try {
                        @Suppress("DEPRECATION") pm.getPackageInfo(a.packageName, PackageManager.GET_ACTIVITIES).activities
                    } catch (_: Exception) { null } ?: continue
                    for (act in acts) {
                        if (!act.exported) continue
                        found.add("$appLabel · ${act.name.substringAfterLast('.')}" to ComponentName(a.packageName, act.name))
                        if (found.size >= 200) break
                    }
                    if (found.size >= 200) break
                }
            } catch (_: Exception) {}
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                list.removeAllViews()
                for ((title, cn) in found) {
                    list.addView(row(title, cn.flattenToShortString(),
                        onLong = { assign(cn) }) {
                        if (!AppUtils.launch(this, cn.flattenToString())) Toast.makeText(this, R.string.cant_open, Toast.LENGTH_SHORT).show()
                    })
                }
                Ui.polish(list)
            }
        }.start()
    }

    private fun assign(cn: ComponentName) {
        val targets = listOf("autohold" to R.string.auto_hold, "vehicle" to R.string.q_vehicle, "drive" to R.string.drive_title,
            "climate" to R.string.q_climate, "camera" to R.string.q_camera,
            "app_dock0" to R.string.app_carplay, "radio" to R.string.chip_radio, "phone" to R.string.nav_phone)
        AlertDialog.Builder(this)
            .setTitle(R.string.s_assign_to)
            .setItems(targets.map { getString(it.second) }.toTypedArray()) { _, i ->
                Prefs.put(this, targets[i].first, cn.flattenToString())
                Toast.makeText(this, R.string.s_assigned, Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun openSettings(action: String, withPackage: Boolean = false) {
        try {
            val i = Intent(action)
            if (withPackage) i.data = android.net.Uri.parse("package:$packageName")
            startActivity(i)
        } catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {}
        }
    }

    // ---------------- builders ----------------

    private fun card(title: Int): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(Ui.dp(context, 20), Ui.dp(context, 16), Ui.dp(context, 20), Ui.dp(context, 18))
        }
        c.addView(TextView(this).apply {
            setText(title); textSize = 19f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(getColor(R.color.text))
        })
        root.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { bottomMargin = Ui.dp(this@SettingsActivity, 14) })
        return c
    }

    private fun label(res: Int) = TextView(this).apply {
        setText(res); textSize = 14f; setTextColor(getColor(R.color.text_dim))
        setPadding(0, Ui.dp(context, 14), 0, Ui.dp(context, 6))
    }

    private fun hint(text: String) = TextView(this).apply {
        this.text = text; textSize = 13f; setTextColor(getColor(R.color.text_dim)); setPadding(0, Ui.dp(context, 6), 0, 0)
    }

    private fun info(text: String) = TextView(this).apply {
        this.text = text; textSize = 15f; setTextColor(getColor(R.color.text)); setPadding(0, Ui.dp(context, 6), 0, Ui.dp(context, 2))
    }

    private fun row(title: String, sub: String? = null, onLong: (() -> Unit)? = null, onClick: () -> Unit): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card_alt)
            setPadding(Ui.dp(context, 16), Ui.dp(context, 12), Ui.dp(context, 16), Ui.dp(context, 12))
            isClickable = true
            setOnClickListener { onClick() }
            if (onLong != null) setOnLongClickListener { onLong(); true }
        }
        r.addView(TextView(this).apply { text = title; textSize = 15f; setTextColor(getColor(R.color.text)) })
        if (sub != null) r.addView(TextView(this).apply {
            text = sub; textSize = 12f; setTextColor(getColor(R.color.text_dim)); textDirection = View.TEXT_DIRECTION_LTR
        })
        r.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = Ui.dp(this@SettingsActivity, 8) }
        return r
    }

    @Suppress("UseSwitchCompatOrMaterialCode")
    private fun switchRow(title: Int, hintRes: Int, on: Boolean, onChange: (Boolean) -> Unit): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card_alt)
            setPadding(Ui.dp(context, 16), Ui.dp(context, 10), Ui.dp(context, 16), Ui.dp(context, 12))
        }
        r.addView(Switch(this).apply {
            setText(title); textSize = 15f; setTextColor(getColor(R.color.text)); isChecked = on
            setOnCheckedChangeListener { _, v -> onChange(v) }
        })
        r.addView(hint(getString(hintRes)))
        r.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = Ui.dp(this@SettingsActivity, 8) }
        return r
    }
}
