package com.fahad.eadolauncher

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import org.osmdroid.views.MapView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.roundToInt

/** Shared look & feel: font, smooth touch, colours, Makkah time. */
object Ui {

    // ---------------- font (Inter, downloaded at build time; system font if missing) ----------------
    private var regular: Typeface? = null
    private var strong: Typeface? = null
    private var loaded = false

    private fun load(c: Context) {
        if (loaded) return
        loaded = true
        fun font(name: String) = try { Typeface.createFromAsset(c.assets, "fonts/$name") } catch (_: Exception) { null }
        regular = font("Main-Regular.ttf")
        strong = font("Main-SemiBold.ttf")
    }

    /** Applies the font and the press animation to a view and everything inside it. */
    fun polish(v: View) {
        load(v.context)
        walk(v)
    }

    private fun walk(v: View) {
        if (v is TextView && v.getTag(R.id.tag_font) == null) {
            val bold = v.typeface?.isBold == true
            (if (bold) strong else regular)?.let { v.typeface = it }
            v.setTag(R.id.tag_font, true)
        }
        if (v.isClickable && v !is MapView && v !is EditText && v !is SeekBar && v.getTag(R.id.tag_touch) == null) {
            v.setOnTouchListener(press)
            v.setTag(R.id.tag_touch, true)
        }
        if (v is ViewGroup && v !is MapView) for (i in 0 until v.childCount) walk(v.getChildAt(i))
    }

    /** iPhone-like press: shrink a little, spring back, light haptic tick. */
    private val press = View.OnTouchListener { view, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).setInterpolator(null).start()
            MotionEvent.ACTION_UP -> {
                view.animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(OvershootInterpolator(2.5f)).start()
                view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            }
            MotionEvent.ACTION_CANCEL ->
                view.animate().scaleX(1f).scaleY(1f).setDuration(200).start()
        }
        false
    }

    // ---------------- colours ----------------
    fun attr(c: Context, attr: Int): Int {
        val tv = TypedValue()
        c.theme.resolveAttribute(attr, tv, true)
        return if (tv.resourceId != 0) c.getColor(tv.resourceId) else tv.data
    }

    fun accent(c: Context) = attr(c, R.attr.accentColor)
    fun accentSoft(c: Context) = attr(c, R.attr.accentSoft)

    val palettes = listOf("sage", "ocean", "sand", "graphite", "ruby")
    val paletteNames = listOf(R.string.pal_sage, R.string.pal_ocean, R.string.pal_sand, R.string.pal_graphite, R.string.pal_ruby)
    val paletteDots = listOf(0xFF3F7A62.toInt(), 0xFF2F6FB3.toInt(), 0xFF9A6B22.toInt(), 0xFF3E474D.toInt(), 0xFFA63A4A.toInt())

    fun themeFor(p: String) = when (p) {
        "ocean" -> R.style.Theme_Launcher_Ocean
        "sand" -> R.style.Theme_Launcher_Sand
        "graphite" -> R.style.Theme_Launcher_Graphite
        "ruby" -> R.style.Theme_Launcher_Ruby
        else -> R.style.Theme_Launcher_Sage
    }

    // ---------------- Makkah time ----------------
    val MAKKAH: TimeZone = TimeZone.getTimeZone("Asia/Riyadh")

    fun isMorning(): Boolean = Calendar.getInstance(MAKKAH).get(Calendar.HOUR_OF_DAY) in 4..11

    fun locale(c: Context): Locale =
        if (Build.VERSION.SDK_INT >= 24) c.resources.configuration.locales[0] else @Suppress("DEPRECATION") c.resources.configuration.locale

    /** e.g. "Friday, 30 October" (Makkah time) */
    fun dateLine(c: Context): String =
        SimpleDateFormat("EEEE, d MMMM", locale(c)).apply { timeZone = MAKKAH }.format(Date())

    // ---------------- small builders ----------------
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).roundToInt()

    /** Row of selectable chips; optional colour dots. */
    fun chips(c: Context, names: List<String>, selected: Int, dots: List<Int>? = null, onPick: (Int) -> Unit): View {
        val scroll = HorizontalScrollView(c).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        scroll.addView(row)
        val views = mutableListOf<View>()
        names.forEachIndexed { i, name ->
            val chip = LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundResource(R.drawable.bg_toggle)
                setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 10))
                isSelected = i == selected
                isClickable = true
            }
            if (dots != null) chip.addView(View(c).apply {
                setBackgroundResource(R.drawable.bg_round)
                backgroundTintList = ColorStateList.valueOf(dots[i])
                layoutParams = LinearLayout.LayoutParams(dp(c, 18), dp(c, 18)).apply { marginEnd = dp(c, 8) }
            })
            chip.addView(TextView(c).apply {
                text = name
                textSize = 15f
                setTextColor(c.getColor(R.color.text))
            })
            chip.setOnClickListener {
                views.forEach { it.isSelected = false }
                chip.isSelected = true
                onPick(i)
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            if (i > 0) lp.marginStart = dp(c, 8)
            row.addView(chip, lp)
            views.add(chip)
        }
        return scroll
    }
}
