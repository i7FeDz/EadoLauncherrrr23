package com.fahad.eadolauncher

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

class LauncherApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppCompatDelegate.setDefaultNightMode(Prefs.nightMode(this))
    }
}
