package com.fahad.eadolauncher

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    fun get(c: Context, key: String): String? = sp(c).getString(key, null)
    fun put(c: Context, key: String, value: String?) = sp(c).edit().putString(key, value).apply()
    fun remove(c: Context, vararg keys: String) {
        val e = sp(c).edit(); keys.forEach { e.remove(it) }; e.apply()
    }

    fun nightMode(c: Context): Int = sp(c).getInt("night", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
    fun setNightMode(c: Context, mode: Int) = sp(c).edit().putInt("night", mode).apply()

    fun name(c: Context): String = get(c, "name")?.takeIf { it.isNotBlank() } ?: c.getString(R.string.default_name)

    /** sage, ocean, sand, graphite, ruby */
    fun palette(c: Context): String = get(c, "palette") ?: "sage"

    /** dp width of the screen: smaller = bigger interface */
    fun uiWidth(c: Context): Int = sp(c).getInt("ui_width", 860)
    fun setUiWidth(c: Context, w: Int) { sp(c).edit().putInt("ui_width", w).commit() }

    /** 0..1, or -1 for "leave the system brightness alone" */
    fun brightness(c: Context): Float = sp(c).getFloat("brightness", -1f)
    fun setBrightness(c: Context, v: Float) = sp(c).edit().putFloat("brightness", v).apply()

    fun lockFun(c: Context): Boolean = sp(c).getBoolean("lock_fun", false)
    fun setLockFun(c: Context, v: Boolean) = sp(c).edit().putBoolean("lock_fun", v).apply()

    fun hotspot(c: Context): Boolean = sp(c).getBoolean("hotspot", true)
    fun setHotspot(c: Context, v: Boolean) = sp(c).edit().putBoolean("hotspot", v).apply()
}
